﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace binary_encryptor
{
    internal class Program
    {
        static void separator()
        {
            for (int i = 0; i < 3; i++)
                Console.WriteLine(" ");
            Console.WriteLine("--------------------------------------------------");
        }
        static string readFile(string filePath)
        {
            using (StreamReader reader = new StreamReader(filePath))
            {
                return reader.ReadToEnd();
            }
        }
        static string binaryEncrypt(string input)
        {
            StringBuilder binary = new StringBuilder();
            foreach (char c in input)
                binary.Append(Convert.ToString(c,2).PadLeft(8, '0'));   
            return binary.ToString();
        }
        static string encrypt(string input, int key)
        {
            StringBuilder encrypted = new StringBuilder();
            foreach (char c in input)
            {
                encrypted.Append((char)(c + key));
            }
            return encrypted.ToString();
        }
        static string decrypt(string input, int key)
        {
            StringBuilder decrypted = new StringBuilder();
            foreach (char c in input)
            {
                decrypted.Append((char)(c - key));
            }
            return decrypted.ToString();
        }
        static void BinaryToInt(string binaryInput)
        {
            binaryInput = binaryInput.Replace("\n", "").Replace("\r", "").Trim();
            StringBuilder text = new StringBuilder();
            StringBuilder decrypted_text = new StringBuilder();
            for (int i = 0; i < binaryInput.Length; i += 8)
            {
                if (i + 8 <= binaryInput.Length)
                {
                    string byteString = binaryInput.Substring(i, 8);
                    int ascii = Convert.ToInt32(byteString, 2); // binary → int
                    char character = (char)ascii;               // int → char
                    text.Append(ascii);
                    decrypted_text.Append(character);
                }
            }
            Console.WriteLine("Your message in int");
            Console.WriteLine(text.ToString());
            Console.WriteLine("Decrypted text from binary:");
            Console.WriteLine(decrypted_text.ToString());
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Enter file path:");
            string input = Console.ReadLine();
            Console.WriteLine("Enter key (integer):");
            int key = int.Parse(Console.ReadLine());
            string content = readFile(input);
            string encryptedContent = encrypt(content, key);
            separator();
            Console.WriteLine("Encrypted content:");
            Console.WriteLine(encryptedContent);
            separator();
            string decryptedContent = decrypt(encryptedContent, key);
            Console.WriteLine("Decrypted content:");
            Console.WriteLine(decryptedContent);
            separator();
            string binaryContent = binaryEncrypt(content);
            Console.WriteLine("Binary representation of original content:");
            Console.WriteLine(binaryContent);
            separator();
            Console.WriteLine("Binary representation of encrypted content:");
            Console.WriteLine(binaryEncrypt(encryptedContent));
            separator();
            Console.WriteLine("Binary representation of decrypted content:");
            Console.WriteLine(binaryEncrypt(decryptedContent));
            separator();
            separator();
            Console.WriteLine("To check if the original binary and the decrypted binary are the same");
            if (binaryEncrypt(content) == binaryEncrypt(decryptedContent))
                Console.WriteLine("Success: The original and decrypted contents match in binary form.");
            else
                Console.WriteLine("Failure: The original and decrypted contents do not match in binary form.");

            separator();
            BinaryToInt(binaryContent);
            Console.ReadLine();
        }
    }
}
